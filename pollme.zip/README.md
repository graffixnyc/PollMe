# PollMe
This is the group Project for CS 546 Web Programming I @ Stevens Institute of Technology

Group Members:

Patrick Hill

Yasuo Kobayashi

Haoyang Li

Seito Ryu

Jason Sarwar

This is a simple application written in nodejs and using mongoDB that allows users to post polls for people to vote on.
